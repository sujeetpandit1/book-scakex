const users = [
    { username: 'admin', password: 'admin', userType: 'admin' },
    { username: 'user', password: 'user', userType: 'regular' },
  ];
  
  module.exports = users;
  